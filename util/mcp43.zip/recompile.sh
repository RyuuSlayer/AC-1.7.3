#!/bin/bash
python runtime/recompile.py "$@"
